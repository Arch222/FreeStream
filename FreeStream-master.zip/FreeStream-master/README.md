FreeStream is a submission in the Web3 Weekend Hackathon sponsored by ETHGlobal.
